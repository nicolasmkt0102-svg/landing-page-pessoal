---
name: Warm Commerce Nexus
colors:
  surface: '#fbf9f5'
  surface-dim: '#dbdad6'
  surface-bright: '#fbf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ef'
  surface-container: '#efeeea'
  surface-container-high: '#eae8e4'
  surface-container-highest: '#e4e2de'
  on-surface: '#1b1c1a'
  on-surface-variant: '#5a4138'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f0ed'
  outline: '#8e7166'
  outline-variant: '#e2bfb2'
  surface-tint: '#a73a00'
  primary: '#a33900'
  on-primary: '#ffffff'
  primary-container: '#cc4900'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb599'
  secondary: '#555f6f'
  on-secondary: '#ffffff'
  secondary-container: '#d6e0f3'
  on-secondary-container: '#596373'
  tertiary: '#825100'
  on-tertiary: '#ffffff'
  tertiary-container: '#a36700'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb599'
  on-primary-fixed: '#370e00'
  on-primary-fixed-variant: '#7f2b00'
  secondary-fixed: '#d9e3f6'
  secondary-fixed-dim: '#bdc7d9'
  on-secondary-fixed: '#121c2a'
  on-secondary-fixed-variant: '#3d4756'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#fbf9f5'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2de'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  metric-num:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 32px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-2xs: 0.25rem
  space-xs: 0.375rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.25rem
  space-xl: 1.75rem
  space-2xl: 2.5rem
---

## Brand & Style

This design system blends **Warm Editorial Minimalism** with high-conversion **Tactile FinTech clarity**. Built specifically for high-performing creator and boutique physical goods commerce, the aesthetic discards sterile, cold software palettes in favor of organic warmth and grounded authority. 

### Key Characteristics
- **Audience & Tone:** Modern entrepreneurs, discerning direct-to-consumer buyers, and established operators. The interface feels established, trustworthy, tactile, and highly energetic.
- **Visual Tension:** A serene, artisanal canvas balanced by precision-engineered, energetic amber/vermilion conversion triggers.
- **Tactility:** Subtle warm-tinted borders, crisp typography, and disciplined density give the UI an authentic, dashboard-grade utility without sacrificing an inviting, human touch.

## Colors

The palette establishes an immediate sense of warmth, premium material quality, and unmistakable action hierarchy:

- **Canvas & Surface (Warm Sand Neutral):**
  - Base Background: `#FDFBF7` (warm off-white/linen).
  - Raised Surface: `#FFFFFF` (pure white for cards, elevated panels, and metric tiles).
  - Recessed Surface: `#F6F3ED` (soft warm gray/sand for inputs, inactive pills, and table headers).
  - Border Subdued: `#E8E2D8` (warm organic divider line).
  - Border Strong: `#D8CFBF`.

- **Action & Energy (Warm Vermilion & Amber):**
  - Primary Action (`#EA580C`): High-conversion primary CTAs, active checkout states, key metrics.
  - Hover / Pressed Accent: `#C2410C`.
  - Vibrant Accent (`#F97316` / `#FF6B35`): Micro-badges, notification pips, conversion highlights, growth graphs.
  - Tertiary Glow / Status (`#F59E0B`): Warning states, pending deliveries, pending fulfillment badges.

- **Typography & High Contrast Neutrals:**
  - Ink Heavy: `#111827` (almost black, deep slate for headlines and primary metrics).
  - Ink Body: `#1F2937` (high legibility body text; never washed out).
  - Ink Subdued: `#4B5563` (secondary context, labels, and timestamps).
  - Disabled / Ghost: `#9CA3AF`.

## Typography

The design system standardizes on **Plus Jakarta Sans** across display, body, and operational metrics. This typeface blends crisp geometric terminals with warm human curves, delivering both high conversion urgency and contemporary editorial style.

- **Contrast Priority:** Faded gray body copy is explicitly forbidden. Primary running text stays anchored in `#1F2937`, ensuring crisp readability across uncalibrated mobile screens and sunlight conditions.
- **Numbers & Dashboards:** Key monetary statistics, revenue streams, and order counts leverage the `metric-num` style with tabular figures (`tnum`) enabled to prevent layout jitter during data updates.

## Layout & Spacing

A compact, balanced spatial cadence tuned for high-density checkout flows and commercial performance dashboards. The grid allows maximum information absorption without visual clutter.

- **Layout Grid:** 
  - Mobile (< 768px): 4-column fluid grid, `1rem` margins, `1rem` gutters.
  - Tablet (768px - 1024px): 8-column fluid grid, `1.5rem` margins, `1rem` gutters.
  - Desktop (> 1024px): 12-column structured grid, maximum content width `1280px`, centered with `2rem` outer margins.
- **Rhythm Rules:**
  - Card inner paddings use compact `space-md` (`0.875rem`) to `space-lg` (`1.25rem`).
  - Gaps between metric indicators and analytical tables are fixed to `space-md`, keeping relationship proximity tight.
  - Data points must stay grouped closely with their labels using `space-2xs` or `space-xs`.

## Elevation & Depth

This system avoids heavy drop shadows and cold neon blurs. Depth is achieved via **tonal layering and warm micro-shadows**:

- **Layer 0 (Canvas):** `#FDFBF7` base canvas.
- **Layer 1 (Cards, Metric Containers, Product Cards):** `#FFFFFF` surface resting on the canvas, bounded by a `1px solid #E8E2D8` border, and an ultra-subtle warm ambient shadow: `0 1px 3px rgba(31, 41, 55, 0.04), 0 1px 2px rgba(234, 88, 12, 0.02)`.
- **Layer 2 (Dropdowns, Floating Summaries, Hover States):** `#FFFFFF` with `0 8px 16px -4px rgba(31, 41, 55, 0.08), 0 2px 6px -2px rgba(234, 88, 12, 0.04)` and `1px solid #D8CFBF`.
- **Layer 3 (Modals & Sheet Drawers):** Backdrop tinted in `#111827` at `35%` opacity with a mild `4px` blur, foreground elevated with `0 20px 25px -5px rgba(31, 41, 55, 0.15)`.
- **Primary CTA Lift:** On hover, primary conversion buttons cast a localized warm halo: `0 4px 12px rgba(234, 88, 12, 0.28)`.

## Shapes

The shape philosophy uses balanced, organic radii (Level 2) that communicate approachability while preserving structured, professional alignments:

- **Base Controls & Inputs:** `0.5rem` (`8px`) border radius.
- **Cards, Panels & Modal Containers:** `0.75rem` to `1rem` (`12px` - `16px`) border radius.
- **Status Pills, Badges & Micro-tags:** Fully pill-shaped (`9999px`) to distinguish categorical metadata from interactive action controls.

## Components

### Buttons
- **Primary Action (Conversion / Buy / Pagar):** Background `#EA580C`, label `#FFFFFF` in `headline-sm` or `body-md` bold. Padding `0.625rem 1.25rem`. Crisp transition to hover `#C2410C` with localized amber ambient glow.
- **Secondary (Inspect / Export / Filter):** Background `#FFFFFF`, border `1px solid #E8E2D8`, label `#1F2937`. Hover changes background to `#F6F3ED` and border to `#D8CFBF`.
- **Tertiary (Ghost / Inline):** Transparent background, label `#EA580C` or `#1F2937` with underlined or bold accent on focus.

### Inputs & Checkout Fields
- **Container:** Height `42px` (compact, ergonomic), background `#FFFFFF`, border `1px solid #E8E2D8`, corner radius `0.5rem`.
- **Typographic Content:** Typed values in `#111827`, placeholder in `#9CA3AF`.
- **Active / Focus:** Border changes directly to `#EA580C` with an outer ring: `0 0 0 3px rgba(234, 88, 12, 0.15)`. No default blue browser focus rings.

### Badges, Tags & Chips
- **Sales / Stock Alert Badge:** Background `rgba(234, 88, 12, 0.10)`, text `#EA580C`, font `label-md`. Border `1px solid rgba(234, 88, 12, 0.20)`.
- **Success / Paid Badge:** Background `#ECFDF5`, text `#065F46`, border `1px solid #A7F3D0`.
- **Pending / Amber Badge:** Background `#FFFBEB`, text `#92400E`, border `1px solid #FDE68A`.
- **Filter Chip:** Pill-shaped, background `#F6F3ED`, border `1px solid #E8E2D8`, text `#1F2937`. Active state flips to `#1F2937` background with `#FFFFFF` text.

### Cards & Commercial Tiles
- **Structure:** Clean white surface (`#FFFFFF`), `1px solid #E8E2D8`, radius `0.75rem`.
- **Metric Tile:** Card with label in `label-md` (`#4B5563`), big value in `metric-num` (`#111827`), accompanied by an inline trending badge in vermilion or forest green.

### Selection Controls (Checkbox & Radio)
- **Checkbox:** `18px x 18px`, radius `4px`, border `1.5px solid #D8CFBF`. Checked state fills `#EA580C` with a white checkmark.
- **Radio:** `18px x 18px`, circular, border `1.5px solid #D8CFBF`. Selected state displays an inner solid circle of `#EA580C`.

### Order & Inventory Lists
- Alternating subtle rows using `#FFFFFF` and `#FDFBF7`. Divider lines using `#E8E2D8`.
- High-contrast SKU and order number labels in `#111827` tabular mono/sans with subtle status badges aligned right.